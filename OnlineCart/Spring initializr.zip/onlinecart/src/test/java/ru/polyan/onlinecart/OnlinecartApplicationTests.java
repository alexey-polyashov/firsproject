package ru.polyan.onlinecart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinecartApplicationTests {

	@Test
	void contextLoads() {
	}

}
